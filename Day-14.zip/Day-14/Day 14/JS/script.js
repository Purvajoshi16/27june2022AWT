$(document).ready(function(){
    $("#agerangeslider").slider({
        min:18,
        max:100,
        value:18,
        slide: function(event,ui){
            $("#agevalue").val(ui.value);
        }
    });
    $("#agevalue").val($("#agerangeslider").slider("value"));
    $("#pricevalue").slider({
        min:1,
        max:500,
        range:true,
        values:[1,50],
        start: function(event,ui){
            $("#startvalue").val("$"+ ui.values[0]);
        },
        stop: function(event,ui){
            $("#endvalue").val("$"+ ui.values[1]);
        },
        change: function(event,ui){
            $("#changevalue").val("$"+ ui.values[0] + "-$" + ui.values[1]);
        },
        slide: function(event,ui){
            $("#slidevalue").val("$"+ ui.values[0] + "-$" + ui.values[1]);
        }
    });
    $(".div1").draggable({
    });
    
    $(".div2 span").draggable({
        containment:".div2"
    });
    $(".div3 span").draggable({
        axis:"x"
    });
    $(".div4 span").draggable({
        axis:"y"
    });
    $(".div5 span").draggable({
        distance:200
    });
    $(".div6 span").draggable({
        delay:1000
    });
    
});