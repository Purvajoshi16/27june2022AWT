//import React from 'react'
function creatJS(){
    alert("Welcome to your Page...");
    console.log('Here is Purva Joshi');
    document.body.style.backgroundColor="green";
    document.getElementById('1').style.backgroundColor="#ffffff";
    document.getElementById('2').style.backgroundColor="blue";
    document.getElementById('3').style.backgroundColor=prompt('Enter a color: ')
}

/*********************************************************/ 

function colorHandler(){
    document.body.style.backgroundColor=document.getElementById('Color1').value;

}
function colorHandler2(){
    document.getElementById("D1").style.backgroundColor=document.getElementById('Color2').value;
}

/*********************************************************/ 

function clickHere(){
    var btn1=prompt('First name')
    var btn2=prompt('last name')
    document.getElementById('S1').innerHTML=btn1;
    document.getElementById('S2').innerHTML=btn2;
    
}

function clickHere2(){

    var bnn=prompt('Enter a name')
    // document.getElementById('S2').innerHTML=bnn;
}

