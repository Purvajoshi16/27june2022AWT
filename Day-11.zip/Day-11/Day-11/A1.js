$(document).ready(function(){
    $("#id1").click(function(){
        alert("Hello");
        $("#meera").hide(5000);
    })
})
$(document).ready(function(){
    $("#id2").click(function(){
        alert("Hello");
        $("#meera").show(5000);
    })
})
$(document).ready(function(){
    $("#id3").click(function(){
        alert("Hello");
        $("#meera").width(200);
        $("#meera").height(200);
    })
})
$(document).ready(function(){
    $("#id4").click(function(){
        alert("Hello");
        $("#meera").width(50);
        $("#meera").height(50);
    })
})
$(document).ready(function(){
$("#id3").click(function(){
    alert("Hello");
    var MDH=parseInt($("#meera").css("height"));
    if(MDH<=150)
    {
        MDH+=10;
        $("#meera").css("height",MDH);
        $("#meera").css("width",MDH);
    }
    else{
        alert("More than 150px is not possible.");
    }
})
});
$(document).ready(function(){
    $("#id4").click(function(){
        alert("Hello");
        var MDH=parseInt($("#meera").css("height"));
        if(MDH>=20)
        {
            MDH-=10;
            $("#meera").css("height",MDH);
            $("#meera").css("width",MDH);
        }
        else{
            alert("less than 20px is not possible.");
        }
    })
    });
    
$("#id2").attr("disabled",true);
$("#id1").click(function(){
    if(confirm("Are you sure..??"))
    {
        $("#meera").hide(3000);
        $(this).attr("disabled",true);
        $("#id2").attr("disabled",false);
    }
})
$("#id2").click(function(){
    if(confirm("Are you sure..??"))
    {
        $("#meera").show(3000);
        $(this).attr("disabled",true);
        $("#id2").attr("disabled",false);
    }
})

